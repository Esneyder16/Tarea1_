/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PrincipalesClases;

import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author Esneyder
 */
public class MenuProductos {
    private ArrayList<Producto> productos;
    private Scanner scanner;

    public MenuProductos() {
        productos = new ArrayList<>();
        scanner = new Scanner(System.in);
    }

    public void mostrarMenu() {//mostrar todo el menu principal
        System.out.println("Hola buenas, estamos a su servicio.");
        System.out.println("1. Crear producto");
        System.out.println("2. Leer productos");
        System.out.println("3. Actualizar producto");
        System.out.println("4. Eliminar producto");
        System.out.println("5. Ver Monto Total");
        System.out.println("6. Ver Información del Producto más caro");
        System.out.println("7. Salir");
    }

    public void crearProducto() {
        System.out.print("Ingrese el nombre del producto: ");
        String nombre = scanner.nextLine();
        System.out.print("Ingrese el precio del producto: ");
        double precio = Double.parseDouble(scanner.nextLine());
        System.out.print("Ingrese la cantidad disponible del producto: ");
        int cantidad = Integer.parseInt(scanner.nextLine());
        productos.add(new Producto(nombre, precio, cantidad));
        System.out.println("Producto agregado con éxito.");
    }

    public void leerProductos() {
        System.out.println("------ Lista de Productos ------");
        for (Producto producto : productos) {
            System.out.println(producto);
        }
    }

    public void actualizarProducto() {
        System.out.print("Ingrese el ID del producto que desea actualizar: ");
        int id = Integer.parseInt(scanner.nextLine());
        for (Producto producto : productos) {
            if (producto.getId() == id) {
                System.out.print("Ingrese el nuevo nombre del producto: ");
                producto.setNombre(scanner.nextLine());
                System.out.print("Ingrese el nuevo precio del producto: ");
                producto.setPrecio(Double.parseDouble(scanner.nextLine()));
                System.out.print("Ingrese la nueva cantidad disponible del producto: ");
                producto.setCantidad(Integer.parseInt(scanner.nextLine()));
                System.out.println("Producto actualizado con éxito.");
                return;
            }
        }
        System.out.println("Producto no encontrado.");
    }

    public void eliminarProducto() {
        System.out.print("Ingrese el ID del producto que desea eliminar: ");
        int id = Integer.parseInt(scanner.nextLine());//se elimina el producto
        for (Producto producto : productos) {
            if (producto.getId() == id) {
                productos.remove(producto);
                System.out.println("Producto eliminado con éxito.");
                return;
            }
        }
        System.out.println("Producto no encontrado.");
    }//fin del metodo eliminarProducto

    public void verMontoTotal() {//ver monto total de los productos
        double total = 0;
        for (Producto producto : productos) {
            total += producto.getPrecio() * producto.getCantidad();
        }
        System.out.println("El monto total de todos los productos es: " + total);
    }

    public void verProductoMasCaro() {
        if (productos.isEmpty()) {
            System.out.println("No hay productos registrados.");
            return;
        }

        Producto masCaro = productos.get(0);
        for (Producto producto : productos) {
            if (producto.getPrecio() > masCaro.getPrecio()) {
                masCaro = producto;
            }
        }
        System.out.println("------ Información del Producto más caro ------");
        System.out.println(masCaro);
    }

    public void ejecutar() {
        while (true) {
            mostrarMenu();
            System.out.print("Ingrese el número de la opción que desea ejecutar: ");
            int opcion = Integer.parseInt(scanner.nextLine());

            switch (opcion) {
                case 1:
                    crearProducto();
                    break;
                case 2:
                    leerProductos();
                    break;
                case 3:
                    actualizarProducto();
                    break;
                case 4:
                    eliminarProducto();
                    break;
                case 5:
                    verMontoTotal();
                    break;
                case 6:
                    verProductoMasCaro();
                    break;
                case 7:
                    System.out.println("¡Hasta luego!");
                    return;
                default:
                    System.out.println("Opción no válida. Por favor, ingrese un número del 1 al 7.");
            }
        }
    }
}//fin de la clase  

