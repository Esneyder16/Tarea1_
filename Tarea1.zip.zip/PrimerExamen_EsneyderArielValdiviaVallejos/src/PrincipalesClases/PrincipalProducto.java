/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PrincipalesClases;

/**
 *
 * @author Esneyder
 */
public class PrincipalProducto {
    public static void main(String[] args) {
        MenuProductos menu = new MenuProductos();
        menu.ejecutar();
   }//fin del main
}//fin de la clase Principal